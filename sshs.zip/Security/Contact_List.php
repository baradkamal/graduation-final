<?php require_once '../src/config/database.php'; ?>
<?php
    require_once '../includes/header.php';
?>
<?php $current_url = 'Contact_List';
include('sidebar.php');
?>
<!-- Profile code start here----------------------------------- -->



<!-- Profile code end  here------------------------------------ -->

<?php
    require_once '../includes/footer.php';
?>